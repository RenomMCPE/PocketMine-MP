<?php

/*
 *
 *     _             _               
 *    / \   _ __ ___ | |__   ___ _ __ 
 *   / _ \ | '_ ` _ \| '_ \ / _ \ '__|
 *  / ___ \| | | | | | |_) |  __/ |   
 * /_/   \_\_| |_| |_|_.__/ \___|_|   
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author AmberPM Team
 * @link https://github.com/Amber-PM/Amber
 *
 *
 */

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\block\utils\DelayedRedstoneReceiver;
use pocketmine\block\utils\RedstoneSignalEmitter;
use pocketmine\block\utils\HorizontalFacing;
use pocketmine\block\utils\HorizontalFacingTrait;
use pocketmine\block\utils\PoweredByRedstone;
use pocketmine\block\utils\PoweredByRedstoneTrait;
use pocketmine\block\utils\RedstoneDiodeTrait;
use pocketmine\block\utils\RedstoneSource;
use pocketmine\block\utils\StaticSupportTrait;
use pocketmine\block\utils\SupportType;
use pocketmine\data\runtime\RuntimeDataDescriber;
use pocketmine\item\Item;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\BlockTransaction;
use pocketmine\world\redstone\RedstoneEngine;

class RedstoneRepeater extends Flowable implements PoweredByRedstone, HorizontalFacing, RedstoneSignalEmitter, RedstoneSource, DelayedRedstoneReceiver{
	use HorizontalFacingTrait;
	use RedstoneDiodeTrait;
	use PoweredByRedstoneTrait;
	use StaticSupportTrait;

	public const MIN_DELAY = 1;
	public const MAX_DELAY = 4;

	protected int $delay = self::MIN_DELAY;

	protected function describeBlockOnlyState(RuntimeDataDescriber $w) : void{
		$w->horizontalFacing($this->facing);
		$w->boundedIntAuto(self::MIN_DELAY, self::MAX_DELAY, $this->delay);
		$w->bool($this->powered);
	}

	public function getDelay() : int{ return $this->delay; }

	/** @return $this */
	public function setDelay(int $delay) : self{
		if($delay < self::MIN_DELAY || $delay > self::MAX_DELAY){
			throw new \InvalidArgumentException("Delay must be in range " . self::MIN_DELAY . " ... " . self::MAX_DELAY);
		}
		$this->delay = $delay;
		return $this;
	}

	protected function recalculateCollisionBoxes() : array{
		return [AxisAlignedBB::one()->trim(Facing::UP, 7 / 8)];
	}

	public function place(BlockTransaction $tx, Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, ?Player $player = null) : bool{
		if($player !== null){
			$this->facing = Facing::opposite($player->getHorizontalFacing());
		}

		return parent::place($tx, $item, $blockReplace, $blockClicked, $face, $clickVector, $player);
	}

	public function onInteract(Item $item, int $face, Vector3 $clickVector, ?Player $player = null, array &$returnedItems = []) : bool{
		if(++$this->delay > self::MAX_DELAY){
			$this->delay = self::MIN_DELAY;
		}
		$this->position->getWorld()->setBlock($this->position, $this);
		return true;
	}

	private function canBeSupportedAt(Block $block) : bool{
		return $block->getAdjacentSupportType(Facing::DOWN) !== SupportType::NONE;
	}

	//TODO: redstone functionality

	public function getRedstoneOutput(int $face, bool $strongOnly, RedstoneEngine $engine) : int{
		return $this->powered && $face === Facing::opposite($this->facing) ? 15 : 0;
	}

	/** A repeater is locked while a powered repeater or comparator points into its side. */
	private function isLocked(RedstoneEngine $engine) : bool{
		foreach([Facing::rotateY($this->facing, true), Facing::rotateY($this->facing, false)] as $side){
			$block = $this->getSide($side);
			if(($block instanceof RedstoneRepeater || $block instanceof RedstoneComparator) && $engine->getOutput($block, Facing::opposite($side), false) > 0){
				return true;
			}
		}
		return false;
	}

	public function onRedstoneUpdate(RedstoneEngine $engine) : void{
		if(!$this->isLocked($engine) && ($this->getRedstoneInput($engine) > 0) !== $this->powered){
			$engine->schedule($this->position, $this->delay * RedstoneEngine::REDSTONE_TICK);
		}
	}

	public function onRedstoneScheduledUpdate(RedstoneEngine $engine) : void{
		$powered = $this->getRedstoneInput($engine) > 0;
		if(!$this->isLocked($engine) && $powered !== $this->powered){
			$engine->getWorld()->setBlock($this->position, $this->setPowered($powered));
			$engine->requestAround($this->position);
		}
	}
}
