<?php

/*
 *
 *     _             _
 *    / \   _ __ ___ | |__   ___ _ __
 *   / _ \ | '_ ` _ \| '_ \ / _ \ '__|
 *  / ___ \| | | | | | |_) |  __/ |
 * /_/   \_\_| |_| |_|_.__/ \___|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author AmberPM Team
 * @link https://github.com/Amber-PM/Amber
 *
 *
 */

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\block\utils\AnalogRedstoneSignalEmitter;
use pocketmine\block\utils\AnalogRedstoneSignalEmitterTrait;
use pocketmine\block\utils\DelayedRedstoneReceiver;
use pocketmine\block\utils\RedstoneSource;
use pocketmine\block\utils\SupportType;
use pocketmine\data\runtime\RuntimeDataDescriber;
use pocketmine\item\Item;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\redstone\RedstoneEngine;
use function cos;
use function max;
use function round;
use const M_PI;

class DaylightSensor extends Transparent implements AnalogRedstoneSignalEmitter, RedstoneSource, DelayedRedstoneReceiver{
	use AnalogRedstoneSignalEmitterTrait;

	protected bool $inverted = false;

	protected function describeBlockOnlyState(RuntimeDataDescriber $w) : void{
		$w->boundedIntAuto(0, 15, $this->signalStrength);
		$w->bool($this->inverted);
	}

	public function isInverted() : bool{
		return $this->inverted;
	}

	/**
	 * @return $this
	 */
	public function setInverted(bool $inverted = true) : self{
		$this->inverted = $inverted;
		return $this;
	}

	public function getFuelTime() : int{
		return 300;
	}

	protected function recalculateCollisionBoxes() : array{
		return [AxisAlignedBB::one()->trim(Facing::UP, 10 / 16)];
	}

	public function getSupportType(int $facing) : SupportType{
		return SupportType::NONE;
	}

	public function onInteract(Item $item, int $face, Vector3 $clickVector, ?Player $player = null, array &$returnedItems = []) : bool{
		$this->inverted = !$this->inverted;
		$this->signalStrength = $this->recalculateSignalStrength();
		$this->position->getWorld()->setBlock($this->position, $this);
		$this->scheduleUpdate(20);
		return true;
	}

	public function onScheduledUpdate() : void{
		$world = $this->position->getWorld();
		$signalStrength = $this->recalculateSignalStrength();
		if($this->signalStrength !== $signalStrength){
			$this->signalStrength = $signalStrength;
			$world->setBlock($this->position, $this);
		}
		$this->scheduleUpdate(20);
	}

	private function scheduleUpdate(int $delay) : void{
		$world = $this->position->getWorld();
		$engine = $world->getRedstoneEngine();
		if($engine !== null){
			$engine->schedule($this->position, $delay, $this->getStateId());
		}else{
			$world->scheduleDelayedBlockUpdate($this->position, $delay);
		}
	}

	public function onRedstoneScheduledUpdate(RedstoneEngine $engine) : void{
		$this->onScheduledUpdate();
	}

	public function onRedstoneUpdate(RedstoneEngine $engine) : void{
		if(!$engine->isScheduled($this->position)){
			$engine->schedule($this->position, 1, $this->getStateId());
		}
	}

	private function recalculateSignalStrength() : int{
		$world = $this->position->getWorld();
		$lightLevel = $world->getRealBlockSkyLightAt($this->position->x, $this->position->y, $this->position->z);
		if($this->inverted){
			return 15 - $lightLevel;
		}

		$sunAngle = $world->getSunAnglePercentage();
		return max(0, (int) round($lightLevel * cos(($sunAngle + ((($sunAngle < 0.5 ? 0 : 1) - $sunAngle) / 5)) * 2 * M_PI)));
	}

	//TODO

	public function getRedstoneOutput(int $face, bool $strongOnly, RedstoneEngine $engine) : int{
		return $strongOnly ? 0 : $this->signalStrength;
	}
}
