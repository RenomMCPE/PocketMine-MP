<?php

/*
 *
 *     _             _
 *    / \   _ __ ___ | |__   ___ _ __
 *   / _ \ | '_ ` _ \| '_ \ / _ \ '__|
 *  / ___ \| | | | | | |_) |  __/ |
 * /_/   \_\_| |_| |_|_.__/ \___|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author AmberPM Team
 * @link https://github.com/Amber-PM/Amber
 *
 *
 */

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\block\utils\AnalogRedstoneSignalEmitter;
use pocketmine\block\utils\AnalogRedstoneSignalEmitterTrait;
use pocketmine\block\utils\RedstoneSource;
use pocketmine\math\Facing;
use pocketmine\world\redstone\RedstoneEngine;
use function ceil;
use function count;
use function max;
use function min;

class WeightedPressurePlate extends PressurePlate implements AnalogRedstoneSignalEmitter, RedstoneSource{
	use AnalogRedstoneSignalEmitterTrait;

	private readonly float $signalStrengthFactor;

	/**
	 * @param float $signalStrengthFactor Number of entities on the plate is divided by this value to get signal strength
	 */
	public function __construct(BlockIdentifier $idInfo, string $name, BlockTypeInfo $typeInfo, int $deactivationDelayTicks, float $signalStrengthFactor = 1.0){
		parent::__construct($idInfo, $name, $typeInfo, $deactivationDelayTicks);
		$this->signalStrengthFactor = $signalStrengthFactor;
	}

	protected function hasOutputSignal() : bool{
		return $this->signalStrength > 0;
	}

	protected function getMaximumSignalEntityCount() : int{
		return $this->signalStrengthFactor > 0 ? (int) ceil(15 / $this->signalStrengthFactor) : 1;
	}

	protected function calculatePlateState(array $entities) : array{
		$newSignalStrength = min(15, max(0,
			(int) ceil(count($entities) * $this->signalStrengthFactor)
		));
		if($newSignalStrength === $this->signalStrength){
			return [$this, null];
		}
		$wasActive = $this->signalStrength !== 0;
		$isActive = $newSignalStrength !== 0;
		return [
			(clone $this)->setOutputSignalStrength($newSignalStrength),
			$wasActive !== $isActive ? $isActive : null
		];
	}

	public function getRedstoneOutput(int $face, bool $strongOnly, RedstoneEngine $engine) : int{
		return !$strongOnly || $face === Facing::DOWN ? $this->signalStrength : 0;
	}
}
