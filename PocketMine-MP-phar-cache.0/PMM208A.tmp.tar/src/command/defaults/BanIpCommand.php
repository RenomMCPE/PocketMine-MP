<?php

/*
 *
 *     _             _               
 *    / \   _ __ ___ | |__   ___ _ __ 
 *   / _ \ | '_ ` _ \| '_ \ / _ \ '__|
 *  / ___ \| | | | | | |_) |  __/ |   
 * /_/   \_\_| |_| |_|_.__/ \___|_|   
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author AmberPM Team
 * @link https://github.com/Amber-PM/Amber
 *
 *
 */

declare(strict_types=1);

namespace pocketmine\command\defaults;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\OverloadedCommand;
use pocketmine\command\overload\GreedyStringArgumentParser;
use pocketmine\lang\KnownTranslationFactory;
use pocketmine\permission\DefaultPermissionNames;
use pocketmine\player\Player;
use function inet_pton;

class BanIpCommand extends OverloadedCommand{

	public function __construct(){
		parent::__construct(
			"ban-ip",
			KnownTranslationFactory::pocketmine_command_ban_ip_description(),
			KnownTranslationFactory::commands_banip_usage()
		);
		$this->setPermission(DefaultPermissionNames::COMMAND_BAN_IP);

		$this->addOverload(
			fn(CommandSender $sender, string $target, string $reason) => $this->run($sender, $target, $reason),
			explicitParsers: ["reason" => new GreedyStringArgumentParser()]
		);
	}

	private function run(CommandSender $sender, string $target, string $reason) : bool{
		if(inet_pton($target) !== false){
			$this->processIpBan($target, $sender, $reason);
			Command::broadcastCommandMessage($sender, KnownTranslationFactory::commands_banip_success($target));

			return true;
		}

		$player = $sender->getServer()->getPlayerByPrefix($target);
		if(!($player instanceof Player)){
			$sender->sendMessage(KnownTranslationFactory::commands_banip_invalid());

			return false;
		}

		$ip = $player->getNetworkSession()->getIp();
		$this->processIpBan($ip, $sender, $reason);
		Command::broadcastCommandMessage($sender, KnownTranslationFactory::commands_banip_success_players($ip, $player->getName()));

		return true;
	}

	private function processIpBan(string $ip, CommandSender $sender, string $reason) : void{
		$sender->getServer()->getIPBans()->addBan($ip, $reason, null, $sender->getName());

		foreach($sender->getServer()->getOnlinePlayers() as $player){
			if($player->getNetworkSession()->getIp() === $ip){
				$player->kick(KnownTranslationFactory::pocketmine_disconnect_ban($reason !== "" ? $reason : KnownTranslationFactory::pocketmine_disconnect_ban_ip()));
			}
		}

		$sender->getServer()->getNetwork()->blockAddress($ip, -1);
	}
}
