<?php

/*
 *
 *     _             _               
 *    / \   _ __ ___ | |__   ___ _ __ 
 *   / _ \ | '_ ` _ \| '_ \ / _ \ '__|
 *  / ___ \| | | | | | |_) |  __/ |   
 * /_/   \_\_| |_| |_|_.__/ \___|_|   
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author AmberPM Team
 * @link https://github.com/Amber-PM/Amber
 *
 *
 */

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\block\tile\Comparator;
use pocketmine\block\utils\AnalogRedstoneSignalEmitter;
use pocketmine\block\utils\AnalogRedstoneSignalEmitterTrait;
use pocketmine\block\utils\DelayedRedstoneReceiver;
use pocketmine\block\utils\HorizontalFacing;
use pocketmine\block\utils\HorizontalFacingTrait;
use pocketmine\block\utils\PoweredByRedstone;
use pocketmine\block\utils\PoweredByRedstoneTrait;
use pocketmine\block\utils\RedstoneDiodeTrait;
use pocketmine\block\utils\RedstoneSource;
use pocketmine\block\utils\StaticSupportTrait;
use pocketmine\block\utils\SupportType;
use pocketmine\data\runtime\RuntimeDataDescriber;
use pocketmine\item\Item;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\BlockTransaction;
use pocketmine\world\redstone\RedstoneEngine;
use function assert;
use function max;

class RedstoneComparator extends Flowable implements AnalogRedstoneSignalEmitter, PoweredByRedstone, HorizontalFacing, RedstoneSource, DelayedRedstoneReceiver{
	use HorizontalFacingTrait;
	use RedstoneDiodeTrait;
	use AnalogRedstoneSignalEmitterTrait;
	use PoweredByRedstoneTrait;
	use StaticSupportTrait;

	protected bool $isSubtractMode = false;

	protected function describeBlockOnlyState(RuntimeDataDescriber $w) : void{
		$w->horizontalFacing($this->facing);
		$w->bool($this->isSubtractMode);
		$w->bool($this->powered);
	}

	public function readStateFromWorld() : Block{
		parent::readStateFromWorld();
		$tile = $this->position->getWorld()->getTile($this->position);
		if($tile instanceof Comparator){
			$this->signalStrength = $tile->getSignalStrength();
		}

		return $this;
	}

	public function writeStateToWorld() : void{
		parent::writeStateToWorld();
		$tile = $this->position->getWorld()->getTile($this->position);
		assert($tile instanceof Comparator);
		$tile->setSignalStrength($this->signalStrength);
	}

	public function isSubtractMode() : bool{
		return $this->isSubtractMode;
	}

	/** @return $this */
	public function setSubtractMode(bool $isSubtractMode) : self{
		$this->isSubtractMode = $isSubtractMode;
		return $this;
	}

	protected function recalculateCollisionBoxes() : array{
		return [AxisAlignedBB::one()->trim(Facing::UP, 7 / 8)];
	}

	public function place(BlockTransaction $tx, Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, ?Player $player = null) : bool{
		if($player !== null){
			$this->facing = Facing::opposite($player->getHorizontalFacing());
		}
		return parent::place($tx, $item, $blockReplace, $blockClicked, $face, $clickVector, $player);
	}

	public function onInteract(Item $item, int $face, Vector3 $clickVector, ?Player $player = null, array &$returnedItems = []) : bool{
		$this->isSubtractMode = !$this->isSubtractMode;
		$this->position->getWorld()->setBlock($this->position, $this);
		return true;
	}

	private function canBeSupportedAt(Block $block) : bool{
		return $block->getAdjacentSupportType(Facing::DOWN) !== SupportType::NONE;
	}

	//TODO: redstone functionality

	public function getRedstoneOutput(int $face, bool $strongOnly, RedstoneEngine $engine) : int{
		return $face === Facing::opposite($this->facing) ? $this->signalStrength : 0;
	}

	/** Compares (or subtracts) the power from the sides with the power from behind, or the container behind. */
	private function computeOutput(RedstoneEngine $engine) : int{
		$rear = $this->getRedstoneInput($engine);
		$containerSignal = $engine->getContainerWatch()->readContainer($this->position->getSide($this->facing));
		$engine->getContainerWatch()->watch($this->position, $containerSignal);
		if($containerSignal !== null){
			$rear = max($rear, $containerSignal);
		}
		$side = max(
			$this->getRedstoneSideInput($engine, Facing::rotateY($this->facing, true)),
			$this->getRedstoneSideInput($engine, Facing::rotateY($this->facing, false))
		);
		return $this->isSubtractMode ? max(0, $rear - $side) : ($rear >= $side ? $rear : 0);
	}

	public function onRedstoneUpdate(RedstoneEngine $engine) : void{
		if($this->computeOutput($engine) !== $this->signalStrength){
			$engine->schedule($this->position, RedstoneEngine::REDSTONE_TICK);
		}
	}

	public function onRedstoneScheduledUpdate(RedstoneEngine $engine) : void{
		$output = $this->computeOutput($engine);
		if($output !== $this->signalStrength){
			$engine->getWorld()->setBlock($this->position, $this->setOutputSignalStrength($output)->setPowered($output > 0));
			$engine->requestAround($this->position);
		}
	}
}
